create definer = rdsadmin@localhost event ev_rds_gsh_table_rotation on schedule
    every '7' DAY
        starts '2024-12-21 04:43:03'
    on completion preserve
    disable
    do
    CALL rds_rotate_global_status_history();

